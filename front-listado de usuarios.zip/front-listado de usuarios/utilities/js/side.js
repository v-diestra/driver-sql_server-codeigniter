	$(document).ready(function(){
        $('#lOrdenes').show(); //muestro mediante id
        $('#cnOrden').hide(); //muestro mediante clase
        $('#mOrdenes').hide(); //muestro mediante clase
        $('#mOrden').hide(); //muestro mediante clase
        $('#aOrden').hide(); //muestro mediante clase

		$("#lOrdenes").on( "click", function() {
			$('#lOrdenes').show(); //muestro mediante id
			$('#cnOrden').hide(); //muestro mediante clase
			$('#mOrdenes').hide(); //muestro mediante clase
			$('#mOrden').hide(); //muestro mediante clase
			$('#aOrden').hide(); //muestro mediante clase
         });
         $("#cnOrden").on( "click", function() {
			$('#lOrdenes').hide(); //muestro mediante id
			$('#cnOrden').show(); //muestro mediante clase
			$('#mOrdenes').hide(); //muestro mediante clase
			$('#mOrden').hide(); //muestro mediante clase
			$('#aOrden').hide(); //muestro mediante clase
		 });

		 $(window).resize(function(){
			if($(window).width()<500){
			 $('.fixed-top').removeClass('fixed-top');
			}
		   });

	});